
public class DictionaryException extends Exception {
	public DictionaryException(String key) {
		super(key);
	}
}
